--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE grupo_2;
--
-- Name: grupo_2; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE grupo_2 WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE grupo_2 OWNER TO postgres;

\connect grupo_2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    cate_cd_id_categoria integer NOT NULL,
    cate_tx_nome character varying(30) NOT NULL,
    cate_tx_descricao character varying(256) NOT NULL
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_cate_cd_id_categoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_cate_cd_id_categoria_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.categoria_cate_cd_id_categoria_seq OWNER TO postgres;

--
-- Name: categoria_cate_cd_id_categoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_cate_cd_id_categoria_seq OWNED BY public.categoria.cate_cd_id_categoria;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_cd_id_endereco integer NOT NULL,
    end_tx_cep character(8) NOT NULL,
    end_tx_numero character varying(5) NOT NULL,
    end_tx_rua character varying(50) NOT NULL,
    end_tx_bairro character varying(20) NOT NULL,
    end_tx_cidade character varying(32) NOT NULL,
    end_tx_uf character varying(2) NOT NULL,
    fk_usu_cd_id_usuario integer
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_cd_id_endereco_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_cd_id_endereco_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.endereco_end_cd_id_endereco_seq OWNER TO postgres;

--
-- Name: endereco_end_cd_id_endereco_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_cd_id_endereco_seq OWNED BY public.endereco.end_cd_id_endereco;


--
-- Name: item_pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.item_pedido (
    itp_cd_id_item_pedido integer NOT NULL,
    itp_int_quantidade integer NOT NULL,
    fk_pro_cd_id_produto integer NOT NULL
);


ALTER TABLE public.item_pedido OWNER TO postgres;

--
-- Name: item_pedido_itp_cd_id_item_pedido_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.item_pedido_itp_cd_id_item_pedido_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.item_pedido_itp_cd_id_item_pedido_seq OWNER TO postgres;

--
-- Name: item_pedido_itp_cd_id_item_pedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.item_pedido_itp_cd_id_item_pedido_seq OWNED BY public.item_pedido.itp_cd_id_item_pedido;


--
-- Name: pedido; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.pedido (
    ped_cd_id_pedido integer NOT NULL,
    ped_dt_datapedido date NOT NULL,
    fk_usu_cd_id_usuario integer NOT NULL,
    fk_itp_cd_id_item_pedido integer
);


ALTER TABLE public.pedido OWNER TO postgres;

--
-- Name: produto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.produto (
    pro_cd_id_produto integer NOT NULL,
    pro_tx_nome character varying(30),
    pro_tx_descriicao character varying(256),
    pro_dt_fabricacao date NOT NULL,
    pro_nm_valor numeric NOT NULL,
    pro_int_estoque integer,
    fk_cate_cd_id_categoria integer NOT NULL,
    fk_usu_cd_id_usuario integer NOT NULL
);


ALTER TABLE public.produto OWNER TO postgres;

--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    usu_cd_id_usuario integer NOT NULL,
    usu_tx_nome character varying(50) NOT NULL,
    usu_tx_login character varying(30) NOT NULL,
    usu_tx_cpf character varying(11) NOT NULL,
    usu_dt_data_nasc date NOT NULL,
    usu_tx_email character varying(75) NOT NULL
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: notafiscal; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.notafiscal AS
 SELECT comprador.usu_tx_nome AS comprador,
    item_pedido.itp_int_quantidade AS quantidade,
    produto.pro_tx_nome AS produto,
    produto.pro_nm_valor AS valor,
    sum((produto.pro_nm_valor * (item_pedido.itp_int_quantidade)::numeric)) AS total,
    vendedor.usu_tx_nome AS vendedor,
    pedido.ped_dt_datapedido AS "data_de_emissão"
   FROM ((((public.pedido
     JOIN public.usuario comprador ON ((comprador.usu_cd_id_usuario = pedido.fk_usu_cd_id_usuario)))
     JOIN public.item_pedido ON ((item_pedido.itp_cd_id_item_pedido = pedido.fk_itp_cd_id_item_pedido)))
     JOIN public.produto ON ((produto.pro_cd_id_produto = item_pedido.fk_pro_cd_id_produto)))
     JOIN public.usuario vendedor ON ((vendedor.usu_cd_id_usuario = produto.fk_usu_cd_id_usuario)))
  GROUP BY comprador.usu_tx_nome, item_pedido.itp_int_quantidade, produto.pro_tx_nome, produto.pro_nm_valor, pedido.ped_dt_datapedido, vendedor.usu_tx_nome;


ALTER TABLE public.notafiscal OWNER TO postgres;

--
-- Name: pedido_ped_cd_id_pedido_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.pedido_ped_cd_id_pedido_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.pedido_ped_cd_id_pedido_seq OWNER TO postgres;

--
-- Name: pedido_ped_cd_id_pedido_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.pedido_ped_cd_id_pedido_seq OWNED BY public.pedido.ped_cd_id_pedido;


--
-- Name: produto_pro_cd_id_produto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.produto_pro_cd_id_produto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.produto_pro_cd_id_produto_seq OWNER TO postgres;

--
-- Name: produto_pro_cd_id_produto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.produto_pro_cd_id_produto_seq OWNED BY public.produto.pro_cd_id_produto;


--
-- Name: telefone; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.telefone (
    num_cd_id_telefone integer NOT NULL,
    num_tx_celular character varying(11),
    fk_usu_cd_id_usuario integer
);


ALTER TABLE public.telefone OWNER TO postgres;

--
-- Name: telefone_num_cd_id_telefone_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.telefone_num_cd_id_telefone_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.telefone_num_cd_id_telefone_seq OWNER TO postgres;

--
-- Name: telefone_num_cd_id_telefone_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.telefone_num_cd_id_telefone_seq OWNED BY public.telefone.num_cd_id_telefone;


--
-- Name: usuario_usu_cd_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_usu_cd_id_usuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuario_usu_cd_id_usuario_seq OWNER TO postgres;

--
-- Name: usuario_usu_cd_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_usu_cd_id_usuario_seq OWNED BY public.usuario.usu_cd_id_usuario;


--
-- Name: categoria cate_cd_id_categoria; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN cate_cd_id_categoria SET DEFAULT nextval('public.categoria_cate_cd_id_categoria_seq'::regclass);


--
-- Name: endereco end_cd_id_endereco; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_cd_id_endereco SET DEFAULT nextval('public.endereco_end_cd_id_endereco_seq'::regclass);


--
-- Name: item_pedido itp_cd_id_item_pedido; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido ALTER COLUMN itp_cd_id_item_pedido SET DEFAULT nextval('public.item_pedido_itp_cd_id_item_pedido_seq'::regclass);


--
-- Name: pedido ped_cd_id_pedido; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido ALTER COLUMN ped_cd_id_pedido SET DEFAULT nextval('public.pedido_ped_cd_id_pedido_seq'::regclass);


--
-- Name: produto pro_cd_id_produto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto ALTER COLUMN pro_cd_id_produto SET DEFAULT nextval('public.produto_pro_cd_id_produto_seq'::regclass);


--
-- Name: telefone num_cd_id_telefone; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone ALTER COLUMN num_cd_id_telefone SET DEFAULT nextval('public.telefone_num_cd_id_telefone_seq'::regclass);


--
-- Name: usuario usu_cd_id_usuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN usu_cd_id_usuario SET DEFAULT nextval('public.usuario_usu_cd_id_usuario_seq'::regclass);


--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria (cate_cd_id_categoria, cate_tx_nome, cate_tx_descricao) FROM stdin;
\.
COPY public.categoria (cate_cd_id_categoria, cate_tx_nome, cate_tx_descricao) FROM '$$PATH$$/3390.dat';

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endereco (end_cd_id_endereco, end_tx_cep, end_tx_numero, end_tx_rua, end_tx_bairro, end_tx_cidade, end_tx_uf, fk_usu_cd_id_usuario) FROM stdin;
\.
COPY public.endereco (end_cd_id_endereco, end_tx_cep, end_tx_numero, end_tx_rua, end_tx_bairro, end_tx_cidade, end_tx_uf, fk_usu_cd_id_usuario) FROM '$$PATH$$/3400.dat';

--
-- Data for Name: item_pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.item_pedido (itp_cd_id_item_pedido, itp_int_quantidade, fk_pro_cd_id_produto) FROM stdin;
\.
COPY public.item_pedido (itp_cd_id_item_pedido, itp_int_quantidade, fk_pro_cd_id_produto) FROM '$$PATH$$/3394.dat';

--
-- Data for Name: pedido; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.pedido (ped_cd_id_pedido, ped_dt_datapedido, fk_usu_cd_id_usuario, fk_itp_cd_id_item_pedido) FROM stdin;
\.
COPY public.pedido (ped_cd_id_pedido, ped_dt_datapedido, fk_usu_cd_id_usuario, fk_itp_cd_id_item_pedido) FROM '$$PATH$$/3396.dat';

--
-- Data for Name: produto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.produto (pro_cd_id_produto, pro_tx_nome, pro_tx_descriicao, pro_dt_fabricacao, pro_nm_valor, pro_int_estoque, fk_cate_cd_id_categoria, fk_usu_cd_id_usuario) FROM stdin;
\.
COPY public.produto (pro_cd_id_produto, pro_tx_nome, pro_tx_descriicao, pro_dt_fabricacao, pro_nm_valor, pro_int_estoque, fk_cate_cd_id_categoria, fk_usu_cd_id_usuario) FROM '$$PATH$$/3392.dat';

--
-- Data for Name: telefone; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.telefone (num_cd_id_telefone, num_tx_celular, fk_usu_cd_id_usuario) FROM stdin;
\.
COPY public.telefone (num_cd_id_telefone, num_tx_celular, fk_usu_cd_id_usuario) FROM '$$PATH$$/3398.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (usu_cd_id_usuario, usu_tx_nome, usu_tx_login, usu_tx_cpf, usu_dt_data_nasc, usu_tx_email) FROM stdin;
\.
COPY public.usuario (usu_cd_id_usuario, usu_tx_nome, usu_tx_login, usu_tx_cpf, usu_dt_data_nasc, usu_tx_email) FROM '$$PATH$$/3388.dat';

--
-- Name: categoria_cate_cd_id_categoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_cate_cd_id_categoria_seq', 5, true);


--
-- Name: endereco_end_cd_id_endereco_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_cd_id_endereco_seq', 5, true);


--
-- Name: item_pedido_itp_cd_id_item_pedido_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.item_pedido_itp_cd_id_item_pedido_seq', 5, true);


--
-- Name: pedido_ped_cd_id_pedido_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.pedido_ped_cd_id_pedido_seq', 5, true);


--
-- Name: produto_pro_cd_id_produto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.produto_pro_cd_id_produto_seq', 18, true);


--
-- Name: telefone_num_cd_id_telefone_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.telefone_num_cd_id_telefone_seq', 5, true);


--
-- Name: usuario_usu_cd_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_usu_cd_id_usuario_seq', 5, true);


--
-- Name: categoria categoria_cate_tx_nome_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_cate_tx_nome_key UNIQUE (cate_tx_nome);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (cate_cd_id_categoria);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_cd_id_endereco);


--
-- Name: item_pedido item_pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido
    ADD CONSTRAINT item_pedido_pkey PRIMARY KEY (itp_cd_id_item_pedido);


--
-- Name: pedido pedido_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT pedido_pkey PRIMARY KEY (ped_cd_id_pedido);


--
-- Name: produto produto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT produto_pkey PRIMARY KEY (pro_cd_id_produto);


--
-- Name: telefone telefone_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone
    ADD CONSTRAINT telefone_pkey PRIMARY KEY (num_cd_id_telefone);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (usu_cd_id_usuario);


--
-- Name: usuario usuario_usu_tx_cpf_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_usu_tx_cpf_key UNIQUE (usu_tx_cpf);


--
-- Name: usuario usuario_usu_tx_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_usu_tx_email_key UNIQUE (usu_tx_email);


--
-- Name: usuario usuario_usu_tx_login_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_usu_tx_login_key UNIQUE (usu_tx_login);


--
-- Name: produto inserir; Type: RULE; Schema: public; Owner: postgres
--

CREATE RULE inserir AS
    ON INSERT TO public.produto
   WHERE (EXISTS ( SELECT produto_1.pro_cd_id_produto,
            produto_1.pro_tx_nome,
            produto_1.pro_tx_descriicao,
            produto_1.pro_dt_fabricacao,
            produto_1.pro_nm_valor,
            produto_1.pro_int_estoque,
            produto_1.fk_cate_cd_id_categoria,
            produto_1.fk_usu_cd_id_usuario
           FROM public.produto produto_1
          WHERE (((produto_1.pro_tx_nome)::text = (new.pro_tx_nome)::text) AND (produto_1.fk_usu_cd_id_usuario = new.fk_usu_cd_id_usuario)))) DO INSTEAD  UPDATE public.produto SET pro_int_estoque = (produto.pro_int_estoque + 1)
  WHERE (((produto.pro_tx_nome)::text = (new.pro_tx_nome)::text) AND (produto.fk_usu_cd_id_usuario = new.fk_usu_cd_id_usuario));


--
-- Name: endereco FK_endereco.fk_usu_cd_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT "FK_endereco.fk_usu_cd_id_usuario" FOREIGN KEY (fk_usu_cd_id_usuario) REFERENCES public.usuario(usu_cd_id_usuario);


--
-- Name: item_pedido FK_item_pedido.fk_pro_cd_id_produto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.item_pedido
    ADD CONSTRAINT "FK_item_pedido.fk_pro_cd_id_produto" FOREIGN KEY (fk_pro_cd_id_produto) REFERENCES public.produto(pro_cd_id_produto);


--
-- Name: pedido FK_pedido.fk_itp_cd_id_item_pedido; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT "FK_pedido.fk_itp_cd_id_item_pedido" FOREIGN KEY (fk_itp_cd_id_item_pedido) REFERENCES public.item_pedido(itp_cd_id_item_pedido);


--
-- Name: pedido FK_pedido.fk_usu_cd_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.pedido
    ADD CONSTRAINT "FK_pedido.fk_usu_cd_id_usuario" FOREIGN KEY (fk_usu_cd_id_usuario) REFERENCES public.usuario(usu_cd_id_usuario);


--
-- Name: produto FK_produto.fk_cate_cd_id_categoria; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT "FK_produto.fk_cate_cd_id_categoria" FOREIGN KEY (fk_cate_cd_id_categoria) REFERENCES public.categoria(cate_cd_id_categoria);


--
-- Name: produto FK_produto.fk_usu_cd_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.produto
    ADD CONSTRAINT "FK_produto.fk_usu_cd_id_usuario" FOREIGN KEY (fk_usu_cd_id_usuario) REFERENCES public.usuario(usu_cd_id_usuario);


--
-- Name: telefone FK_telefone.fk_usu_cd_id_usuario; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.telefone
    ADD CONSTRAINT "FK_telefone.fk_usu_cd_id_usuario" FOREIGN KEY (fk_usu_cd_id_usuario) REFERENCES public.usuario(usu_cd_id_usuario);


--
-- PostgreSQL database dump complete
--

